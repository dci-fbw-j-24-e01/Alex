package com.example.f10_pagingSorting.controllers;

import com.example.f10_pagingSorting.db.CityRepository;
import com.example.f10_pagingSorting.models.City;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mapping.PropertyReferenceException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CityController {

    @Autowired
    CityRepository cityRepository;

    @GetMapping("/")
    public String root(@RequestParam(name = "page", required = false, defaultValue = "1") Integer urlPageNumber,
                       @RequestParam(name = "page_size", required = false, defaultValue = "20") Integer pageSize,
                       @RequestParam(name = "order", required = false, defaultValue = "id") String order,
                       Model model) {

        int pageNumber = urlPageNumber - 1;

        Sort.Direction direction = Sort.Direction.ASC;

        if (order.endsWith("desc")) {
            direction = Sort.Direction.DESC;
            order = order.substring(0, order.length() - 5);
        }
        Sort sort = Sort.by(direction, order);
        org.springframework.data.domain.Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
        Page<City> page;
        try {
            page = cityRepository.findAll(pageable);
        } catch (PropertyReferenceException e) {
            return root(urlPageNumber, pageSize, "id", model);
        }
        model.addAttribute("cities", page.getContent());
        model.addAttribute("pageNumber", urlPageNumber);
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("totalPages", page.getTotalPages());
        model.addAttribute("order", sort.toString());

        return "index";
    }


    // Exercise:
    // Create a page where you show a table with the cities in the DB
    // use pagination to show only 50 cities in each page
    // pagination should have a Next button and a Previous button
    // those buttons should only be enabled/visible if there is a next or previous
    //
    //
    // BONUS 1:
    // Add a select that allows you to choose between 20, 50, 100 or 200 cities at a time
    //
    // BONUS 2:
    // Add a select that allows you to sort by
    // - Default (by id)
    // - Name ASC
    // - Name DESC
    // - Pop ASC
    // - POP DESC
    //
    // BONUS 3:
    // Add number buttons to the page navigator
    // You should show a maximum of 6 number buttons in case there are more than 6 pages
    // <First> <Previous> <1> <2> ... <4> <5> <Next> <Last>
}
