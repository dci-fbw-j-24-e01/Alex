package com.example.f10_pagingSorting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class F10PagingSortingApplication {

	public static void main(String[] args) {
		SpringApplication.run(F10PagingSortingApplication.class, args);
	}

}
