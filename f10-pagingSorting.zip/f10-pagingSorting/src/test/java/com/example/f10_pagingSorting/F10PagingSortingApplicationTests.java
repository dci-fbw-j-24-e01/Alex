package com.example.f10_pagingSorting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class F10PagingSortingApplicationTests {

	@Test
	void contextLoads() {
	}

}
